# PIEC
 Python Integrated Experimental Control
 The goal of this repository is to provide a streamlined control scheme for lab experiments and allow for rapid development
 of new experimental procedures starting from a ferroelectric standpoint.
 Requires KEYSIGHT I/O Libraries, find them here: www.keysight.com/find/iosuite
