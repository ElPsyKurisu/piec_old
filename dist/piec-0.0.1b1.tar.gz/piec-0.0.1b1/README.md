# PIEC
 Python Integrated Experimental Control
 The Goal of this repository is to provide a streamlined control scheme for lab experiments and allow for rapid development
 of new experimental procedures starting from a ferroelectric standpoint.
